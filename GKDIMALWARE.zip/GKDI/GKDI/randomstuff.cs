﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GKDI
{
    internal class randomstuff
    {
        public string RandomGen()
        {
            string chars = "qwertyuiopasdfghjklzxcvbnm1234567890";
            Random rand = new Random();
            int stringLength = 10;

            StringBuilder output = new StringBuilder();

            for (int i = 0; i < 666; i++)
            {
                StringBuilder result = new StringBuilder();

                for (int j = 0; j < stringLength; j++)
                {
                    int index = rand.Next(chars.Length);
                    result.Append(chars[index]);
                }

                output.AppendLine(result.ToString());
            }

            return output.ToString();
        }
    }
}
