﻿using Cluttscape_tutorial;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GKDI
{
    internal class LASTGDI
    {
        public void gdi_payload()
        {
            int count = 1000;
            while (true)
            {
                Random rand;
                rand = new Random();
                int x = Screen.PrimaryScreen.Bounds.Width; int y = Screen.PrimaryScreen.Bounds.Height;
                IntPtr hdc = dport.GetDC(IntPtr.Zero);
                dport.StretchBlt(hdc, (rand.Next(2) == 1) ? -1 : 1, (rand.Next(2) == 1) ? -1 : 1, x, y, hdc, 0, 0,
                x, y, dport.TernaryRasterOperations.SRCAND);
                dport.DeleteDC(hdc);
                if (count != 10)
                    Thread.Sleep(count -= 10);
                else
                    Thread.Sleep(1);
            }
        }
    }
}
